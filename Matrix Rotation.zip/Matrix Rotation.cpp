#include <iostream>
#include <cstdio>
#include <algorithm>

#define N 4
using namespace std;

//direc : -1 = left, 1 = right
void normalRot(int Mat[][4], int direc, int count){
	count %= 4;
	if (!count) return;
	int newMat[N][N];
	if (count == 3) direc *= -1; count = 1;

	int * ps = *Mat, *pd = *newMat, i, j;

	if (direc == -1){
		pd += (N * (N - 1));
		for (i = 0; i < N; i++){
			for (j = 0; j < N; j++){
				*pd = *ps++;
				pd -= N;
			}
			pd += (N * N + 1);
		}
	}
	else{
		pd += (N - 1);
		for (i = 0; i < N; i++){
			for (j = 0; j < N; j++){
				*pd = *ps++;
				pd += N;
			}
			pd -= (N * N + 1);
		}
	}

	for (i = 0; i < N * N; i++)
		*(ps + i) = *(pd + i);
	
	return;
}

int main(){
	int Mat[N][N] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
	normalRot(Mat, -1, 1);

	for (int i = 0; i < N; i++)
		cout << **(Mat + i) << endl;

	return 0;
} 